import java.time.LocalDate;
import java.util.Locale;

public abstract class Medicine {
    //Medicine – an abstract class.
    //Attributes: medicine name, company name, company email,
    //quantity, quantity (num of box), expirationYear (YYYY ), typeOfMedicine (from enum)
    //Methods: constructors, getters and setters, toString(),
    //totalInventory() - an abstract method to calculate the total
    //inventory for each medicine type (ex: 1 Acamol box has 50
    //pills, if we have 1000 boxes = total 1000X50),
    //inStock() – returns true if the quantity > 0 else returns false

    //Attributes
    private String medicineName;
    private String companyName;
    private String companyEmail;
    private int quantity;
    private int expirationYear;
    private TypeOfMedicine typeOfMedicine;
    private double price;

    //constant for '@' (char)
    final char SHTRUDEL_CHAR = '@';

    //constant for "@" (String)
    final String SHTRUDEL_STR = "@";

    //constant for "." (String)
    final String DOT_STR = ".";

    //constant for "." (char)
    final char DOT_CHAR = '.';

    //Constructors
    public Medicine()
    {

    }

    public Medicine(String medicineName, String companyName, String companyEmail, double price, int quantity, int expirationYear, TypeOfMedicine typeOfMedicine) {
        setMedicineName(medicineName);
        setCompanyName(companyName);
        setCompanyEmail(companyEmail);
        setPrice(price);
        setQuantity(quantity);
        setExpirationYear(expirationYear);
        setTypeOfMedicine(typeOfMedicine);
    }

    //getters
    public String getMedicineName() {
        return medicineName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getCompanyEmail() {
        return companyEmail;
    }

    public double getPrice() {
        return quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getExpirationYear() {
        return expirationYear;
    }

    public TypeOfMedicine getTypeOfMedicine() {
        return typeOfMedicine;
    }

    //setters

    public void setMedicineName(String medicineName) {
        try {
            // Throw an object of user defined My exception
            if (medicineName == null)
                throw new MyException("No medicine name entered");
            else
                this.medicineName = medicineName.toUpperCase();

        } catch (MyException ex) {
            ex.printStackTrace();

        }
    }

    public void setCompanyName(String companyName) {
        try {
            // Throw an object of user defined My exception
            if (companyName == null)
                throw new MyException("No company name entered");
            else
                this.companyName = companyName;

        } catch (MyException ex) {
            ex.printStackTrace();

        }

    }

    public void setCompanyEmail(String companyEmail) {
        try {
            // Throw an object of user defined My exception
            if (companyEmail == null)
                throw new MyException("No company email entered");
            else if (companyEmail.contains(SHTRUDEL_STR) && companyEmail.contains(DOT_STR))
                if (companyEmail.charAt(0) != SHTRUDEL_CHAR && !(companyEmail.endsWith(SHTRUDEL_STR)) && companyEmail.lastIndexOf(DOT_CHAR) > companyEmail.lastIndexOf(SHTRUDEL_CHAR))
                    this.companyEmail = companyEmail;
                else
                    throw new MyException( companyEmail + " InvalidEmailAddressException");
            else
                throw new MyException( companyEmail + " InvalidEmailAddressException");

        } catch (MyException ex) {
            ex.printStackTrace();
        }
    }

    public void setPrice(double price) {
        try {
            // Throw an object of user defined My exception
            if (price == 0.0)
                throw new MyException("No price entered");

            else if(price > 0.0)
                    this.price = price;
                else
                    throw new MyException("The price: " + price + " invalid");


        } catch (MyException ex) {
            ex.printStackTrace();
        }

    }

    public void setQuantity(int quantity) {
        try {
                if(quantity >= 0) {
                    this.quantity = quantity;
                }
            else
                throw new MyException("The quantity: " + quantity + " invalid");


        } catch (MyException ex) {
            ex.printStackTrace();
        }
    }

    public void setExpirationYear(int expirationYear) {
        LocalDate yearCurObj ;
        yearCurObj = LocalDate.now();

        try {
            if(expirationYear >= yearCurObj.getYear())
                this.expirationYear = expirationYear;
            else
                throw new MyException(expirationYear + " invalidExpirationYear");
        }catch (MyException myException)
        {
            myException.printStackTrace();
        }
    }

    public void setTypeOfMedicine(TypeOfMedicine typeOfMedicine) {
        this.typeOfMedicine = typeOfMedicine;
    }

    //Method toString
    public String toString()
    {
     return "Medicine name: " + medicineName + ", Company Name: " + companyName + ", Company email: "  + companyEmail + ", Price: "  + price  +
             ", Quantity: " + quantity + ", Expiration year: " + expirationYear +  ", Type of medicine: " + typeOfMedicine;

    }

    //totalInventory() - an abstract method to calculate the total
    //inventory for each medicine type (ex: 1 Acamol box has 50
    //pills, if we have 1000 boxes = total 1000X50),
    public abstract int totalInventory();

    //inStock() –The method returns true if the quantity > 0 else returns false
    public boolean inStock()
    {
        return ((getQuantity()>0));

    }

}
