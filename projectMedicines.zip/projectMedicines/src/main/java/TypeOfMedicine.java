public enum TypeOfMedicine {
    //enum with the values : PILLS, SYRUP and INHALER
    INHALER,
    PILLS,
    SYRUP

}
