import java.util.jar.Attributes;

public class Pills extends Medicine {
    //extends from Medicine
    //Attributes: (מספר כדורים) numOfPillsInBox
    //Methods: Constructors, getters and setters, override of
    //toString(), override of totalInventory()


    //Attributes
    private int numOfPillsInBox;

    //constructors
    public Pills() {

    }

    public Pills(String medicineName, String companyName, String companyEmail, double price, int quantity, int expirationYear, int numOfPillsInBox) {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, TypeOfMedicine.PILLS);
        setNumOfPillsInBox(numOfPillsInBox);
    }

    //getters
    public int getNumOfPillsInBox() {
        return numOfPillsInBox;
    }

    //setters
    public void setNumOfPillsInBox(int numOfPillsInBox) {
        //constants
         final int MIN_NUM_OF_PILLS_IN_BOX = 0;
         final int MAX_NUM_OF_PILLS_IN_BOX = 300;
        try {
            if(numOfPillsInBox > MIN_NUM_OF_PILLS_IN_BOX && numOfPillsInBox < MAX_NUM_OF_PILLS_IN_BOX)
                this.numOfPillsInBox = numOfPillsInBox;
            else
                throw new MyException(numOfPillsInBox + " invalidNumOfPillsInBox");
        }catch (MyException myException)
        {
            myException.printStackTrace();
        }

    }

    //override of toString()
    public String toString()
    {
        return super.toString() + ", num of pills in box: " + numOfPillsInBox;
    }

    //override of totalInventory()


    @Override
    public int totalInventory() {
        return (numOfPillsInBox*super.getQuantity());
    }
}
