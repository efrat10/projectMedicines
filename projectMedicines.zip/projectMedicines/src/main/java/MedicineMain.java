import java.util.ArrayList;
import java.util.Scanner;

public class MedicineMain {

    //create obj for Scanner
    static Scanner  input = new Scanner(System.in);

    //create a new inventory
    static Inventory inventory = new Inventory();

    public static void main(String[] args) {
        // Main Class:
        //1) create a new inventory
        //2) create 3 medicines of each type add them to the inventory
        //3) search for a specific medicine by name
        //4) search for all medicines by type
        //5) prints all medicines in stock
        //6) try to add an existing Medicine to the Inventory
        //7) Search for a non-existing Medicine
        //8) Try to add a medicine with an incorrect e-mail


        //create 3 medicines of each types

        // medicine with an incorrect e-mail
        Pills acamolyP = new Pills("acamoly","sofa","sofagmail.com",32,400,2030,30);
        Pills decsamol = new Pills("decsamol","sofa","sofagmail.com",18,45,2022,35);

        Syrup noraphenS = new Syrup("noraphen","relax","relax@co.il",45,270,2028,180);

        //medicine with invalid expiration year (smaller than the current year)
        Inhaler abcdI = new Inhaler("abcdI","saga","saga@il.gov",52.5,300,2021,44);

        //medicine without company email
        Inhaler abcdI2 = new Inhaler("abcdI","saga",null,52.5,300,2027,44);
        Inhaler cccc = new Inhaler("cccc","saga",null,52.5,0,2027,44);

        //Adding the created objects to the inventory
        inventory.addMedicine(abcdI);
        inventory.addMedicine(noraphenS);
        inventory.addMedicine(acamolyP);
        inventory.addMedicine(decsamol);

        //try to add an existing Medicine to the Inventory
        inventory.addMedicine(abcdI2);

        //prints all medicines in stock
        System.out.println("printing all medicines in stock");
        for (Medicine medicine: inventory.getListOfMedicine()) {
            if(medicine.inStock())
            System.out.println(medicine.toString());

        }

        //Search for a specific medicine by name
        //Reference to a searchByNameMain()
        searchByNameMain();

        //Search for all medicines by type
        //Reference to a searchByTypeMain()
        searchByTypeMain();

    }

    //The method gets a name medicine for  search and Reference to a searchMedicineByName() – that returns a medicine according
    // to its name and prints its total Inventory.
    public static void searchByNameMain()
    {
        String nameMedicineFromUser = null;
        String medicineReturnStr;

        //Receiving a medicine name for search from the user
        System.out.println("enter the medicine name to search");
        nameMedicineFromUser = input.next();

        medicineReturnStr = inventory.searchMedicineByName(nameMedicineFromUser);
        try {
            if(medicineReturnStr != null)
                System.out.println(medicineReturnStr);
            else
                throw new MyException("MedicineDoesNotExistException");
        }catch (MyException myException)
        {
            myException.printStackTrace();
        }

    }

    //The function receives a search type from the user,
    // and sends it to searchByType  function that returns an array and sends it to a printArr function
    public static void searchByTypeMain() {
        int numOfType = 0;
        ArrayList<Medicine> medicinesOfType = new ArrayList<>();
        TypeOfMedicine type = TypeOfMedicine.PILLS;
        //receiving a search type from the user
        System.out.println("enter type to search:\n" + Constants.NUM_FOR_PILLS + " for pills\n" + Constants.NUM_FOR_SYRUP + " for syrup\n" + Constants.NUM_FOR_INHALER + " for inhaler");
        while (numOfType != Constants.NUM_FOR_PILLS && numOfType != Constants.NUM_FOR_SYRUP && numOfType != Constants.NUM_FOR_INHALER) {
            try {
                numOfType = input.nextInt();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        switch (numOfType) {
            case 2 -> type = TypeOfMedicine.SYRUP;
            case 3 -> type = TypeOfMedicine.INHALER;
        }
            //Sending the type to searchMedicineByType func and receiving ArrayList from it
            medicinesOfType=inventory.searchMedicineByType(type);
            //Sending ArrayList to printArr func that print it
            printArr(medicinesOfType);
        }

        //The func prints arrayList
        public static void printArr(ArrayList<Medicine> medicineArrayList){
            for ( Medicine medicine: medicineArrayList) {
                System.out.println(medicine.toString());

            }

        }




}
