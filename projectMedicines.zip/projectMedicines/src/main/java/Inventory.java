import java.util.ArrayList;

public class Inventory {
    //Inventory – class contains array list of all Medicines
    //Methods:
    //Constructors, getters and setters,
    //addMedicine() – adds new medicine to array list
    //Validation: Before adding a new medicine to the Inventory
    //check if medicine name already exists.
    //If so throw a new MedicineAlreadyExistException .
    //searchMedicineByName() – returns a medicine according
    //to its name and prints its total Inventory.
    //If the Medicine does not exists throws a new
    //MedicineDoesNotExistException.
    //Tip: The searchMedicineByName should be
    //case insensitive – use the equalsIgnoreCase.
    //searchMedicineByType() – returns an array list of
    //medicines by its type.
    //getMedicinesInStock() - return array list of all medicines in stock

    private ArrayList<Medicine> listOfMedicine = new ArrayList<>();

    //getters
    public ArrayList<Medicine> getListOfMedicine() {
        return listOfMedicine;
    }

    //addMedicine() – adds new medicine to array list
    public void addMedicine(Medicine medicine)
    {
        //Validation: Before adding a new medicine to the Inventory
        // check if medicine name already exists.
        // If so throw a new MedicineAlreadyExistException .
       try {
           if(!isMedicineExist(medicine.getMedicineName()))
               listOfMedicine.add(medicine);
           else
               throw new MyException("MedicineAlreadyExistException " + medicine.getMedicineName());
       }catch (MyException myException)
       {
           myException.printStackTrace();
       }

    }

    //The method check if the medicine already exist
    //it gets a name of medicine and return true if exist and false if don't
    public boolean isMedicineExist(String medicineName)
    {
        boolean flag = false;
        for (Medicine medicine:listOfMedicine) {
            if (medicine.getMedicineName().equalsIgnoreCase(medicineName)) {
                flag = true;
                break;
            }

        }
        return flag;
    }

    //searchMedicineByName() – returns a medicine according
    // to its name and prints its total Inventory.
    public String searchMedicineByName(String medicineName){
        Medicine medicineFound = null;
        boolean flag = false;
        for (int i = 0; i < listOfMedicine.size() && !flag; i++) {

            if(listOfMedicine.get(i).getMedicineName().equalsIgnoreCase( medicineName))
            {
                medicineFound =listOfMedicine.get(i) ;
                flag=true;

            }
        }
        return (flag) ? medicineFound.toString()  + "\nTotal inventory: " + medicineFound.totalInventory() : null;

    }

    //print
    public ArrayList getListAllMedicineInStock()
    {
        return listOfMedicine;
    }

    //The method gets the type to search and returns an array list of medicines by its type.
    public ArrayList<Medicine> searchMedicineByType(TypeOfMedicine typeOfMedicine){
        ArrayList<Medicine> listOfMedicineByType = new ArrayList<>();

        for ( Medicine medicine:listOfMedicine )
        {
          if(medicine.getTypeOfMedicine().equals(typeOfMedicine))

              listOfMedicineByType.add(medicine);

        }
        return listOfMedicineByType;

    }


}
