public class Constants {
    final static int NUM_FOR_PILLS = 1;
    final static int NUM_FOR_SYRUP = 2;
    final static int NUM_FOR_INHALER = 3;
}
