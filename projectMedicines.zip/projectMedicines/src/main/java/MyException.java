public class  MyException extends Exception {
    // A Class that represents use-defined MyException

    //class to handle invalid values in
    //medicine details.


        public MyException(String s)
        {
            // Call constructor of parent Exception
            super(s);
        }

}
