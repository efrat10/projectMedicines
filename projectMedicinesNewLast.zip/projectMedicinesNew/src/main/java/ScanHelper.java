

import java.time.LocalDate;
import java.util.Scanner;

public class ScanHelper {

    //Create an obj for Scanner
    static Scanner input = new Scanner(System.in);

    //The function receives from the user his selection from the main menu
    //Loops until valid input and returns that value
    public static int UserInputFromTheMainMenu(){
        int choice =0;
        String tmp ="";
        boolean flag = false;//if was NumberFormatException in main menu, flag will be true else it will be false

            //Executes the loop until a valid value is selected
            do{
                if(flag) {
                    if(tmp.length() == 0)
                        System.out.println("Nothing entered, please enter!");
                    else
                    System.out.println("No valid choice was entered, please enter a number between 1 and 6");
                }
                flag = false;
                //Receiving input from the user
                try {
                    tmp = input.nextLine();
                    if(tmp.length() !=1)
                        flag = true;
                    else {
                        choice = Integer.parseInt(tmp);
                        if(choice != Constants.CHOICE1 && choice != Constants.CHOICE2 && choice != Constants.CHOICE3 && choice != Constants.CHOICE4 && choice != Constants.CHOICE5 && choice != Constants.CHOICE6)
                            flag = true;
                    }
                } catch (NumberFormatException numberFormatException) {
                    //numberFormatException.printStackTrace();
                    flag = true;
                }
        }while (flag);
        return choice;
    }

    //The function asks a type of medicine from the user, and returns it.
    // and sends it to searchByType  function that returns an array and sends it to a printArr function
    public static Medicine.Type typeMedicineFromUser(){
        int numOfType = 0;
        String tmp ="";
        Medicine.Type type;
        boolean flag = false;

        //receiving a search type from the user
        System.out.println("Enter type:\n" + Constants.NUM_FOR_PILLS + " for pills\n" + Constants.NUM_FOR_SYRUP + " for syrup\n" + Constants.NUM_FOR_INHALER + " for inhaler");
        do {
            if(flag)
            {
                if(tmp.length() == 0)
                    System.out.println("Nothing entered, please enter!");
                else
                System.out.println("No valid choice was entered, please enter a number between 1 and 3");
            }

            flag =false;
            try{
                tmp = input.nextLine();
                if(tmp.length() !=1)
                    flag =true;
                if(!flag) {
                    numOfType = Integer.parseInt(tmp);
                    if (numOfType != Constants.NUM_FOR_PILLS && numOfType != Constants.NUM_FOR_SYRUP && numOfType != Constants.NUM_FOR_INHALER)
                        flag = true;
                }
            }catch (NumberFormatException n)
            {
                //n.printStackTrace();
                flag = true;
            }
        }while (flag);
        type = switch (numOfType) {
            case 2 -> Medicine.Type.SYRUP;
            case 3 -> Medicine.Type.INHALER;
            default -> Medicine.Type.PILLS;
        };
        return type;
    }

    public static String inputMedicineName(){
        String str;
        System.out.println("Enter name of the medicine:");
        str = inputString(20, "name Medicine");
        return str;
    }
    public static String inputCompanyName(){
        String str;
        System.out.println("Enter company Name of the medicine");
        str = inputString(Constants.MAX_CHARACTERS_FOR_COMPANY_NAME, "company name");
        return str;
    }
    public static String inputCompanyEmail(){
        String companyEmail;
        boolean flag;
        int lastIndexDot;
        int lastIndexShtrudel;
        System.out.println("Enter company email");
        do{
            flag = false;
            companyEmail = inputString(Constants.MAX_CHARACTERS_FOR_COMPANY_EMAIL, "company email");

            lastIndexDot = companyEmail.lastIndexOf(Constants.DOT_CHAR);
            lastIndexShtrudel = companyEmail.lastIndexOf(Constants.SHTRUDEL_CHAR);

            if (companyEmail.contains(Constants.SHTRUDEL_STR) && companyEmail.contains(Constants.DOT_STR))
                if ((companyEmail.endsWith(Constants.SHTRUDEL_STR)) || (companyEmail.endsWith(Constants.DOT_STR))
                        || (companyEmail.startsWith(Constants.SHTRUDEL_STR)) || (companyEmail.startsWith(Constants.DOT_STR)) || (lastIndexDot < lastIndexShtrudel) || (lastIndexShtrudel+1 == lastIndexDot)) {

                    flag = true;
                }
                else
                    flag = false;
            else
                flag = true;
            if (flag)
                System.out.println("The email address is invalid, please enter again");

        }while (flag);

        return companyEmail;
    }
    public static double inputPrice(){
        double price;
        boolean flag;
        System.out.println("Enter price");
        do {
            flag = false;
            price = inputDouble("price");
            if(price<=0) {
                flag = true;
                System.out.println("The price should be greater than 0, please press again");
            }
        } while (flag);

        return price;
    }
    public static int inputQuantity(){
        int quantity;
        System.out.println("Enter quantity");
        quantity = inputIntOverZero("quantity",Constants.MAX_CHARACTERS_FOR_QUANTITY);
        return quantity;
    }
    public static int inputExpirationYear(){
        int expirationYear;
        boolean flag;
        LocalDate yearCurObj ;
        yearCurObj = LocalDate.now();
        System.out.println("Enter expiration year");
        do {
            flag = false;
            expirationYear = inputIntOverZero("expiration Year",Constants.MAX_CHARACTERS_FOR_EXPIRATION_YEAR);
            if (expirationYear < yearCurObj.getYear()) {
                flag = true;
                System.out.println("The year has expired, please enter again");
            }
        }while (flag);

        return expirationYear;
    }
    public static int inputAmountOfClick(){
        int amountOfClick;
        System.out.println("Enter amount Of Click");
        amountOfClick = inputIntOverZero("Amount Of Click" , Constants.MAX_CHARACTERS_FOR_AMOUNT_OF_CLICK);
        return amountOfClick;
    }
    public static int inputBottleContent(){
        int bottleContent;
        System.out.println("Enter bottle Content");
        bottleContent = inputIntOverZero("bottle Content", Constants.MAX_CHARACTERS_BOTTLE_CONTENT);
        return bottleContent;
    }
    public static int numOfPillsInBox(){
        int numOfPillsInBox;
        System.out.println("enter number Of Pills In Box");
        numOfPillsInBox = inputIntOverZero("num Of Pills In Box",Constants.MAX_CHARACTERS_NUM_OF_PILLS_IN_BOX);
        return numOfPillsInBox;
    }

    //The function accepts a string from the user and return its
    public static String inputString(int maxCharacters,String nameVar){
        String str;
        boolean flag;
        do
        {
            flag = false;
            str = input.nextLine();
            if(str.length() > maxCharacters) {
                System.out.println("You cannot enter more than " + maxCharacters + " characters for " + nameVar +", please enter again!");
                flag = true;
            }
            else if(str.trim().length() == 0) {
                    System.out.println("Nothing entered for " + nameVar +", please enter!");
                    flag = true;
                }
        }while (flag);
        return str;
    }

    //The function accept a integer from the user and return its
    public static int inputIntOverZero(String nameVar,int maxCharacters) {
        String tmp;
        boolean flag;
        int number = 0;
        do {
            flag = false;
            tmp = inputString(maxCharacters,nameVar);
            if (tmp.contains(" ")) {
                System.out.println("Please enter a number without a space");
                flag = true;
            } else if (tmp.contains(Constants.DOT_STR)) {
                System.out.println("Decimal number cannot be entered for " + nameVar + " please enter a whole number");
                flag = true;
            }
            if (!flag) {
                try {
                    number = Integer.parseInt(tmp);
                } catch (NumberFormatException e) {
                    //e.printStackTrace();
                    System.out.println("An invalid value was entered, please enter a valid value for " +nameVar);
                    flag = true;
                }
                if(number<=0 && !flag) {
                    flag = true;
                    System.out.println("The " + nameVar+" should be greater than 0, please press again");
                }
            }

        } while (flag);
        return number;
    }


    //The function accept a double from the user
    public static double inputDouble(String nameVar) throws NumberFormatException{
        String tmp;
        boolean flag;
        double number = 0;

        do{
            flag = false;
            tmp = inputString(9,nameVar);
            try {
                number = Double.parseDouble(tmp);
            }catch (NumberFormatException n){
                System.out.println("An invalid value was entered for " + nameVar + ", please enter a valid value");
                flag = true;
            }
        }while (flag);

        return number;
    }
}
