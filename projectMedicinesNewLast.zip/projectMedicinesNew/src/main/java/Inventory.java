import java.util.ArrayList;
import java.util.Collections;
import exception.*;

public class Inventory {
    //Inventory – class contains array list of all Medicines
    //Methods:
    //Constructors, getters and setters,
    //addMedicine() – adds new medicine to array list
    //Validation: Before adding a new medicine to the Inventory
    //check if medicine name already exists.
    //If so throw a new MedicineAlreadyExistException .
    //searchMedicineByName() – returns a medicine according
    //to its name and prints its total Inventory.
    //If the Medicine does not exists throws a new
    //MedicineDoesNotExistException.
    //Tip: The searchMedicineByName should be
    //case insensitive – use the equalsIgnoreCase.
    //searchMedicineByType() – returns an array list of
    //medicines by its type.
    //getMedicinesInStock() - return array list of all medicines in stock

    private ArrayList<Medicine> listOfMedicine = new ArrayList<>();

    //addMedicine() – adds new medicine to array list
    public void addMedicine(Medicine medicine) throws MedicineAlreadyExistException {
        //Validation: Before adding a new medicine to the Inventory
        // check if medicine name already exists.
        // If so throw a new MedicineAlreadyExistException .

           if(!isMedicineExist(medicine.getMedicineName()))
               listOfMedicine.add(medicine);
           else
               throw new MedicineAlreadyExistException(" " + medicine.getMedicineName());
    }

    //The method check if the medicine already exist
    //it gets a name of medicine and return true if exist and false if don't
    public boolean isMedicineExist(String medicineName)
    {
        boolean flag = false;
        for (Medicine medicine:listOfMedicine) {
            if (medicine.getMedicineName().equalsIgnoreCase(medicineName)) {
                flag = true;
                break;
            }

        }
        return flag;
    }

    //searchMedicineByName() – returns a medicine according
    // to its name and prints its total Inventory.
    public Medicine searchMedicineByName(String medicineName) throws MedicineDoesNotExistException {
        Medicine medicineFound = null;
        boolean flag = false;
        for (int i = 0; i < listOfMedicine.size() && !flag; i++) {

            if(listOfMedicine.get(i).getMedicineName().equalsIgnoreCase( medicineName))
            {
                medicineFound =listOfMedicine.get(i) ;
                flag=true;
            }
        }
        if(!flag)
            throw new MedicineDoesNotExistException(medicineName);
        else
        return medicineFound;
    }

    //print all medicines in stock
    public ArrayList<Medicine> getListAllMedicineInStock(boolean bool) {
        ArrayList<Medicine> medicinesInStockArr = new ArrayList<>();
        for (Medicine medicine : listOfMedicine)
            if (medicine.inStock() == bool)
                medicinesInStockArr.add(medicine);
            return medicinesInStockArr;
        }

        //The method gets the type to search and returns an array list of medicines by its type.
        public ArrayList<Medicine> searchMedicineByType (Medicine.Type type)
        {
        ArrayList<Medicine> listOfMedicineByType = new ArrayList<>();

        for ( Medicine medicine:listOfMedicine )
        {

                if(medicine.getType().equals(type))

                    listOfMedicineByType.add(medicine);


        }
        return listOfMedicineByType;

        }

    }



