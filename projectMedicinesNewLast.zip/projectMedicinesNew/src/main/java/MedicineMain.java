import java.util.ArrayList;
import java.util.Scanner;
import exception.*;
//new
public class MedicineMain {

    //create obj for Scanner
    static Scanner input = new Scanner(System.in);

    //create a new obj for Inventory
    static Inventory inventory = new Inventory();


    public static void main(String[] args) {
        // Main Class:
        //1) create a new inventory
        //2) create 3 medicines of each type add them to the inventory
        //3) search for a specific medicine by name
        //4) search for all medicines by type
        //5) prints all medicines in stock
        //6) try to add an existing Medicine to the Inventory
        //7) Search for a non-existing Medicine
        //8) Try to add a medicine with an incorrect e-mail

        //Create an obj for Scanner

        int choice = 0;
        boolean flagAddMedicine = true;


        ArrayList<Medicine> medicinesOfType = new ArrayList<>();

        //create medicines of each type and adding them to the inventory
        try {
            Pills medicine1 = new Pills("Acamoly", "teva", "teva@gmail.com", 40, 6, 2030, 30);
            inventory.addMedicine(medicine1);
            Pills medicine2 = new Pills("Dexamol", "dexcel", "dexcel@mail.com", 18.5, 45, 2023, 20);
            inventory.addMedicine(medicine2);
            Syrup medicine3 = new Syrup("Noraphen", "relax", "relax@co.il", 45, 270, 2028, 180);
            inventory.addMedicine(medicine3);
            Syrup medicine7 = new Syrup("Ferripel", "cts", "cts@co.il", 27, 270, 2024, 15);
            inventory.addMedicine(medicine7);

            Inhaler medicine4 = new Inhaler("Sodium", "saga", "saga@org.il", 52.5, 300, 2024, 44);
            inventory.addMedicine(medicine4);
            Inhaler medicine5 = new Inhaler("Chlorid", "natrol", "natrol@co.il", 52.5, 300, 2027, 44);
            inventory.addMedicine(medicine5);
            Inhaler medicine6 = new Inhaler("acamol porta", "natrol", "natrol@org.il", 52.5, 13, 2027, 100);
            inventory.addMedicine(medicine6);


        } catch (MyException m) {
            m.printStackTrace();
        }

        //Calling to func that print main menu
        PrintingHelper.mainMenu();

        //Executes the loop as long as the number 6 is not selected from the menu (exit)
        while (choice != Constants.CHOICE6) {

            //calling the func that returns the user's selection from the main menu (int between 1 and 6)
            choice = ScanHelper.UserInputFromTheMainMenu();

            switch (choice) {
                case 1:
                    //Printing all medicine in stock
                    PrintingHelper.allMedicineInStock(inventory.getListAllMedicineInStock(true));
                    break;

                case 2:
                    //Printing all medicine that not in stock
                    PrintingHelper.allMedicineNotInStock(inventory.getListAllMedicineInStock(false));
                    break;

                case 3:
                    //Adding a new medicine
                    try {
                        addMedicineMain(ScanHelper.typeMedicineFromUser());
                        flagAddMedicine = false;
                    } catch (MedicineAlreadyExistException e) {
                        e.printStackTrace();
                        flagAddMedicine = true;
                    } finally {
                        if (!flagAddMedicine)
                            System.out.println("The medicine was added successfully");
                    }


                    break;
                    case 4:
                        //Search for a specific medicine by name
                        //Reference to a searchByNameMain()
                        try {
                            searchByNameMain();
                        } catch (MedicineDoesNotExistException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 5: {
                        //Printing all medicine according to type That received from user

                        //Sending the type that received from the user to searchMedicineByType func and receiving ArrayList from it
                        medicinesOfType = inventory.searchMedicineByType(ScanHelper.typeMedicineFromUser());

                        //Sending ArrayList to printArr func that print it
                        if (medicinesOfType.size() > 0) {
                            System.out.println("----Printing medicines By type----");
                            PrintingHelper.printArr(medicinesOfType);
                        } else
                            System.out.println("There is no such medicine for this type");
                    }


                }
                    //A reference to the method that displays a main menu to the user
                    if (choice != Constants.CHOICE6)
                        PrintingHelper.mainMenu();

            }
        }


        //The method gets typeOfMedicine
        //depending on the type received:
        //create an obj
        //A call to a function that will receive medicine characteristics from the user and execute a set command
        //Receiving additional characteristics unique to type medicine, and executing the set command
        //Adding the medicine to the inventory
        public static void addMedicineMain(Medicine.Type typeOfMedicine ) throws   MedicineAlreadyExistException {
            switch (typeOfMedicine) {
                case PILLS -> {
                    Pills pills = new Pills();
                    setMedicine(pills);
                    pills.setNumOfPillsInBox(ScanHelper.numOfPillsInBox());
                    pills.setType(Medicine.Type.PILLS);
                    inventory.addMedicine(pills);
                }
                case SYRUP -> {
                    Syrup syrup = new Syrup();
                    setMedicine(syrup);
                    syrup.setBottleContent(ScanHelper.inputBottleContent());
                    syrup.setType(Medicine.Type.SYRUP);
                    inventory.addMedicine(syrup);
                }
                case INHALER -> {
                    Inhaler inhaler = new Inhaler();
                    setMedicine(inhaler);
                    inhaler.setAmountOfClick(ScanHelper.inputAmountOfClick());
                    inhaler.setType(Medicine.Type.INHALER);
                    inventory.addMedicine(inhaler);
                }
            }
    }

    //The method gets medicine obj and call the func that asks form user values to Characters medicine and set them in obj by set func.
    public static void setMedicine(Medicine medicine) {
        medicine.setMedicineName(ScanHelper.inputMedicineName());
        medicine.setCompanyName(ScanHelper.inputCompanyName());
        medicine.setCompanyEmail(ScanHelper.inputCompanyEmail());
        medicine.setPrice(ScanHelper.inputPrice());
        medicine.setQuantity(ScanHelper.inputQuantity());
        medicine.setExpirationYear(ScanHelper.inputExpirationYear());
    }


    //The method asks from user a name medicine for  search and Reference to a searchMedicineByName() – that returns a medicine according
    // to its name and prints its total Inventory or throw MedicineDoesNotExistException.
    public static void searchByNameMain() throws  MedicineDoesNotExistException {
        String nameMedicineFromUser;
        Medicine medicineReturn;
        //Receiving a medicine name for search from the user
        nameMedicineFromUser = ScanHelper.inputMedicineName();
        medicineReturn = inventory.searchMedicineByName(nameMedicineFromUser);
                System.out.println("The " + medicineReturn.getMedicineName() + " exists in inventory" +
                        " and the total inventory is: " + medicineReturn.totalInventory() + "\n" + medicineReturn);
    }

    }


