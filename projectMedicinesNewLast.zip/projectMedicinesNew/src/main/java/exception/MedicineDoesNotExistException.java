package exception;
public class MedicineDoesNotExistException extends MyException{
    /* To be thrown if a searched medicine does not exist in
    the inventory
     */

    public MedicineDoesNotExistException(String name) {
        super("ERROR :: The " + name + " medicine does not exist in the inventory" );
    }
}
