public class Constants {
    final static int NUM_FOR_PILLS = 1;
    final static int NUM_FOR_SYRUP = 2;
    final static int NUM_FOR_INHALER = 3;
    final static int MAX_CHARACTERS_BOTTLE_CONTENT = 4;
    final static int MAX_CHARACTERS_NUM_OF_PILLS_IN_BOX = 3;
    final static int MAX_CHARACTERS_FOR_EXPIRATION_YEAR = 4;
    final static int MAX_CHARACTERS_FOR_QUANTITY = 5;
    final static int MAX_CHARACTERS_FOR_AMOUNT_OF_CLICK = 5;
    final static int MAX_CHARACTERS_FOR_COMPANY_EMAIL = 20;
    final static int MAX_CHARACTERS_MEDICINE_NAME = 20;
    final static int MAX_CHARACTERS_FOR_COMPANY_NAME = 20;


    //constant for '@' (char)
    final static char SHTRUDEL_CHAR = '@';

    //constant for "@" (String)
    final static String SHTRUDEL_STR = "@";

    //constant for "." (String)
    final static String DOT_STR = ".";

    //constant for "." (char)
    final static char DOT_CHAR = '.';

    final static int CHOICE1 = 1;
    final static int CHOICE2 = 2;
    final static int CHOICE3 = 3;
    final static int CHOICE4 = 4;
    final static int CHOICE5 =5;
    final static int CHOICE6 =6;
    final static int CHOICE0 = 0;
}
