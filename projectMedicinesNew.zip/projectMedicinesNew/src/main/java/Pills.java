import java.util.jar.Attributes;
import exception.*;
public class Pills extends Medicine {
    //extends from Medicine
    //Attributes: (מספר כדורים) numOfPillsInBox
    //Methods: Constructors, getters and setters, override of
    //toString(), override of totalInventory()


    //Attributes
    private int numOfPillsInBox;

    //constructors
    public Pills() {

    }

    public Pills(String medicineName, String companyName, String companyEmail, double price, int quantity, int expirationYear, int numOfPillsInBox) throws MyException {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, Type.PILLS);
        setNumOfPillsInBox(numOfPillsInBox);
    }

    //getters
    public int getNumOfPillsInBox() {
        return numOfPillsInBox;
    }

    //setters
    public void setNumOfPillsInBox(int numOfPillsInBox) throws InvalidNumOfPillsInBoxException {
        //constants
         final int MIN_NUM_OF_PILLS_IN_BOX = 0;
         final int MAX_NUM_OF_PILLS_IN_BOX = 300;

            if(numOfPillsInBox > MIN_NUM_OF_PILLS_IN_BOX && numOfPillsInBox < MAX_NUM_OF_PILLS_IN_BOX)
                this.numOfPillsInBox = numOfPillsInBox;
            else
                throw new InvalidNumOfPillsInBoxException("" +numOfPillsInBox);

    }

    //override of toString()
    public String toString()
    {
        return super.toString() + ", num of pills in box: " + numOfPillsInBox;
    }

    //override of totalInventory()


    @Override
    public int totalInventory() {
        return (numOfPillsInBox*super.getQuantity());
    }
}
