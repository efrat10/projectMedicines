package exception;
public class InvalidQuantityException extends MyException{
    public InvalidQuantityException() {
    }

    public InvalidQuantityException(String s) {
        super(s);
    }
}
