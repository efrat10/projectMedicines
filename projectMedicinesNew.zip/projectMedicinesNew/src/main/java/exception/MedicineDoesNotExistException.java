package exception;
public class MedicineDoesNotExistException extends MyException{
    public MedicineDoesNotExistException() {
    }

    public MedicineDoesNotExistException(String s) {
        super(s);
    }
}
