package exception;
public class AddingTheDrugFailedException extends MyException{
    public AddingTheDrugFailedException() {
    }

    public AddingTheDrugFailedException(String s) {
        super(s);
    }
}
