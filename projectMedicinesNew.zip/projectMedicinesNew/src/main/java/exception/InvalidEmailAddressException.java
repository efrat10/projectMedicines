package exception;
public class InvalidEmailAddressException extends MyException {
    public InvalidEmailAddressException(String s) {
        super(s);
    }

    public InvalidEmailAddressException() {

    }
}
