package exception;
public class InvalidPriceException extends MyException {
    public InvalidPriceException() {
    }

    public InvalidPriceException(String s) {
        super(s);
    }
}
