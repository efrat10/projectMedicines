package exception;
public class InvalidBottleContentException extends MyException{
    public InvalidBottleContentException() {
    }

    public InvalidBottleContentException(String s) {
        super(s);
    }
}
