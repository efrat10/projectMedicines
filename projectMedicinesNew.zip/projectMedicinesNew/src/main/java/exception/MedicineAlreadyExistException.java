package exception;
public class MedicineAlreadyExistException extends MyException{
    public MedicineAlreadyExistException() {
    }

    public MedicineAlreadyExistException(String s) {
        super(s);
    }
}
