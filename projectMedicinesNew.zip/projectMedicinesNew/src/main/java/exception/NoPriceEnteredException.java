package exception;
public class NoPriceEnteredException extends MyException{
    public NoPriceEnteredException() {
    }

    public NoPriceEnteredException(String s) {
        super(s);
    }
}
