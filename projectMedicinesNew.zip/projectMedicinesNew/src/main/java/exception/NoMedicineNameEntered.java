package exception;
public class NoMedicineNameEntered extends MyException {
    public NoMedicineNameEntered() {
    }

    public NoMedicineNameEntered(String s) {
        super(s);
    }
}
