package exception;
public class NoCompanyNameEntered extends MyException{
    public NoCompanyNameEntered() {
    }

    public NoCompanyNameEntered(String s) {
        super(s);
    }
}
