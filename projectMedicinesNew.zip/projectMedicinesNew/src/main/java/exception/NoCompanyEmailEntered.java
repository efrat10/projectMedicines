package exception;
public class NoCompanyEmailEntered extends MyException{
    public NoCompanyEmailEntered() {
    }

    public NoCompanyEmailEntered(String s) {
        super(s);
    }
}
