package exception;
public class invalidExpirationYearException extends MyException{
    public invalidExpirationYearException() {
    }

    public invalidExpirationYearException(String s) {
        super(s);
    }
}
