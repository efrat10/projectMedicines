package exception;
public class NotAllMedicineWereIncludedInTheInventoryException extends MyException {
    public NotAllMedicineWereIncludedInTheInventoryException() {
    }

    public NotAllMedicineWereIncludedInTheInventoryException(String s) {
        super(s);
    }
}
