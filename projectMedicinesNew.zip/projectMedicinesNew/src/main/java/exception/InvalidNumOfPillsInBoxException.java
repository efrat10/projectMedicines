package exception;
public class InvalidNumOfPillsInBoxException extends MyException{
    public InvalidNumOfPillsInBoxException() {
    }

    public InvalidNumOfPillsInBoxException(String s) {
        super(s);
    }
}
