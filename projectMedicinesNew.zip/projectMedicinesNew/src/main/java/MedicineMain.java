import java.util.ArrayList;
import java.util.Scanner;
import exception.*;
//new
public class MedicineMain {

    //create obj for Scanner
    static Scanner input = new Scanner(System.in);

    //create a new obj for inventory
    static Inventory inventory = new Inventory();

    public static void main(String[] args)  {
        // Main Class:
        //1) create a new inventory
        //2) create 3 medicines of each type add them to the inventory
        //3) search for a specific medicine by name
        //4) search for all medicines by type
        //5) prints all medicines in stock
        //6) try to add an existing Medicine to the Inventory
        //7) Search for a non-existing Medicine
        //8) Try to add a medicine with an incorrect e-mail

        //Create an obj for Scanner
        Scanner input = new Scanner(System.in);
        int choice =0;
        String tmp;
        final int CHOICE1 = 1;
        final int CHOICE2 = 2;
        final int CHOICE3 = 3;
        final int CHOICE4 = 4;
        final int CHOICE5 =5;
        final int CHOICE6 =6;
        boolean flag = false;//if was NumberFormatException in main menu, flag will be true else it will be true
        boolean flagSearchByType;
        boolean flagAddMedicine = true;


        ArrayList<Medicine> medicinesOfType = new ArrayList<>();

        //create medicines of each type and adding them to the inventory
        try {
            Pills medicine1 = new Pills("Acamoly", "teva", "teva@gmail.com", 40, 0, 2030, 30);
            inventory.addMedicine(medicine1);
            Pills medicine2 = new Pills("Dexamol", "dexcel", "dexcel@mail.com", 18, 45, 2022, 20);
            inventory.addMedicine(medicine2);
            Syrup medicine3 = new Syrup("Noraphen", "relax", "relax@co.il", 45, 270, 2028, 180);
            inventory.addMedicine(medicine3);
            Syrup medicine7 = new Syrup("Ferripel", "cts", "cts@co.il", 27, 270, 2024, 15);
            inventory.addMedicine(medicine7);

            Inhaler medicine4 = new Inhaler("Sodium", "saga", "saga@org.il", 52.5, 300, 2024, 44);
            inventory.addMedicine(medicine4);
            Inhaler medicine5 = new Inhaler("Chlorid", "natrol", "natrol@co.il", 52.5, 300, 2027, 44);
            inventory.addMedicine(medicine5);
            Inhaler medicine6 = new Inhaler("Melatonin", "", "natrol@org.il", 52.5, 12, 2027, 100);
            inventory.addMedicine(medicine6);



        }catch (MyException myException) {
            myException.printStackTrace();
            flag = true;
        }
        finally {
            try {
                if (flag)
                    throw new NotAllMedicineWereIncludedInTheInventoryException("There is at least one invalid value in the inventory,\n That's why not all medicines were entered into the database ");
            }catch (NotAllMedicineWereIncludedInTheInventoryException e){
                e.printStackTrace();
                flag = false;
            }
        }

        //Executes the loop as long as the number 6 is not selected from the menu (exit)
            while(choice != CHOICE6) {
                //Executes the loop until a valid value is selected
                while (choice != CHOICE1 && choice != CHOICE2 && choice != CHOICE3 && choice != CHOICE4 && choice != CHOICE5) {
                    ////A reference to the method that displays a main menu to the user
                    mainMenu();
                    //Receiving input from the user
                    try {
                        tmp = input.next();
                        choice = Integer.parseInt(tmp);
                        flag = false;
                    } catch (NumberFormatException numberFormatException) {
                        numberFormatException.printStackTrace();
                        flag = true;
                        break;
                    }
                }
                //If the input is correct
                    if (!flag)
                    {

                    switch (choice) {
                        case 1:
                            printAllInStock();
                            break;


                        case 2:
                            printAllNotInStock();
                            break;


                        case 3:
                            try {
                                addMedicineMain(typeMedicineFromUser());
                                flagAddMedicine = true;
                            } catch (NumberFormatException | InvalidPriceException | InvalidQuantityException | invalidExpirationYearException | InvalidEmailAddressException | NoMedicineNameEntered | NoPriceEnteredException | NoCompanyEmailEntered | NoCompanyNameEntered | InvalidNumOfPillsInBoxException | MedicineAlreadyExistException | InvalidBottleContentException e ) {
                                e.printStackTrace();
                                flagAddMedicine = false;
                            }
                            finally {
                                try{
                                if(flagAddMedicine)
                                    System.out.println("The medicine was added successfully");

                                else throw new AddingTheDrugFailedException();
                                }catch (AddingTheDrugFailedException e){
                                    e.printStackTrace();
                                }

                            }
                            break;
                        case 5: {

                            //Sending the type that received from the user to searchMedicineByType func and receiving ArrayList from it
                            try {
                                medicinesOfType = inventory.searchMedicineByType(typeMedicineFromUser());
                                flagSearchByType = false;
                            } catch (NumberFormatException numberFormatException) {
                                numberFormatException.printStackTrace();
                                flagSearchByType = true;
                            }

                            //Sending ArrayList to printArr func that print it
                            if(!flagSearchByType){
                                System.out.println("----Printing medicines By type----");
                                printArr(medicinesOfType);
                            }
                        }
                        break;
                        case 4:
                            //Search for a specific medicine by name
                            //Reference to a searchByNameMain()
                            try {
                                searchByNameMain();
                            } catch (MedicineDoesNotExistException e) {
                                e.printStackTrace();
                            }
                            break;
                    }
                    }

                    //A reference to the method that displays a main menu to the user
                    mainMenu();
                    try {
                        tmp = input.next();
                        choice = Integer.parseInt(tmp);
                        flag = false;
                    }catch (NumberFormatException in){
                        in.printStackTrace();
                        flag = true;

                    }
                }

                }

    //The Methods

    //The method displays a main menu to the user
    public static void mainMenu() {
        System.out.println("\nChoose from the menu\n" +
                " 1. Printing all medications in stock\n" + " 2. Printing all out-of-stock medications\n" +
                " 3. Adding a medicine\n 4. Searching for a medicine By name\n 5. Searching for medicines by type\n" +
                " 6. For exit\n");
    }
    //The method Prints all out-of-stock medications
    public static void printAllNotInStock()
    {
        System.out.println("----Printing all out of stock medication----");
        inventory.getListAllMedicineInStock(false);
        for (Medicine medicine : inventory.getListAllMedicineInStock(false))
            System.out.println(medicine.toString());
    }

    //The method Print all in stock medications
    public static void printAllInStock()
    {
        System.out.println("----Printing all medication in stock----");
        inventory.getListAllMedicineInStock(true);
        for (Medicine medicine : inventory.getListAllMedicineInStock(true))
            System.out.println(medicine.toString());
    }

        //The method gets typeOfMedicine
        //depending on the type received:
        //create an obj
        //A call to a function that will receive medicine characteristics from the user and execute a set command
        //Receiving additional characteristics unique to pills medicine, and executing the set command
        //Adding the medicine to the inventory
        public static void addMedicineMain(Medicine.Type typeOfMedicine ) throws NumberFormatException, InvalidPriceException, InvalidQuantityException, invalidExpirationYearException, InvalidEmailAddressException, NoMedicineNameEntered, NoPriceEnteredException, NoCompanyEmailEntered, NoCompanyNameEntered, InvalidNumOfPillsInBoxException, MedicineAlreadyExistException, InvalidBottleContentException {
            switch (typeOfMedicine) {
                case PILLS -> {
                    Pills pills = new Pills();
                    setMedicine(pills);
                    System.out.println("enter number Of Pills In Box");
                    pills.setNumOfPillsInBox(inputInt());
                    pills.setType(Medicine.Type.PILLS);
                    inventory.addMedicine(pills);
                }
                case SYRUP -> {
                    Syrup syrup = new Syrup();
                    setMedicine(syrup);
                    System.out.println("Enter bottle Content");
                    syrup.setBottleContent(inputInt());
                    syrup.setType(Medicine.Type.SYRUP);
                    inventory.addMedicine(syrup);
                }
                case INHALER -> {
                    Inhaler inhaler = new Inhaler();
                    setMedicine(inhaler);
                    System.out.println("Enter amount Of Click");
                    inhaler.setAmountOfClick(inputInt());
                    inhaler.setType(Medicine.Type.INHALER);
                    inventory.addMedicine(inhaler);
                }
            }
    }

    //The method gets medicine obj and asks form user values to Characters medicine and set them in obj.
    public static void setMedicine(Medicine medicine) throws NumberFormatException, NoMedicineNameEntered, NoCompanyNameEntered, InvalidEmailAddressException, NoCompanyEmailEntered, InvalidPriceException, NoPriceEnteredException, InvalidQuantityException, invalidExpirationYearException {
        System.out.println("Enter name of the medicine:");
        medicine.setMedicineName(inputString());
        System.out.println("Enter company Name of the medicine");
        medicine.setCompanyName(inputString());
        System.out.println("Enter company email");
        medicine.setCompanyEmail(inputString());
        System.out.println("Enter price");
        medicine.setPrice(inputDouble());
        System.out.println("Enter quantity");
        medicine.setQuantity(inputInt());
        System.out.println("Enter expiration Year");
        medicine.setExpirationYear(inputInt());
    }

    //The function accepts a string from the user and return its
    public static String inputString(){
        String str;
        str = input.next();
        while (str.length() >25)
        {
            System.out.println("don't entered a valid input, please enter again!");
            str = input.next();
        }
        return str;
    }

    //The function accept a integer from the user and return its
    public static int inputInt() throws NumberFormatException{
        String tmp;
        tmp = input.next();
        return Integer.parseInt(tmp);
    }

    //The function accept a double from the user
    public static double inputDouble() throws NumberFormatException{
        String tmp;
        tmp = input.next();

        return Double.parseDouble(tmp);
    }


    //The method asks from user a name medicine for  search and Reference to a searchMedicineByName() – that returns a medicine according
    // to its name and prints its total Inventory.
    public static void searchByNameMain() throws MedicineDoesNotExistException {
        String nameMedicineFromUser;
        Medicine medicineReturn;
        //Receiving a medicine name for search from the user
        System.out.println("Enter the medicine name to search");
        nameMedicineFromUser = input.next();
        medicineReturn = inventory.searchMedicineByName(nameMedicineFromUser);
                System.out.println("The " + medicineReturn.getMedicineName() + " exists in inventory" +
                        " and the total inventory is: " + medicineReturn.totalInventory() + "\n" + medicineReturn);
    }

    //The function asks a type of medicine from the user, and returns it.
    // and sends it to searchByType  function that returns an array and sends it to a printArr function
    public static Medicine.Type typeMedicineFromUser() throws NumberFormatException{
        int numOfType = 0;
        String tmp;
        ArrayList<Medicine> medicinesOfType = new ArrayList<>();
        Medicine.Type type;
        //receiving a search type from the user
        System.out.println("Enter type:\n" + Constants.NUM_FOR_PILLS + " for pills\n" + Constants.NUM_FOR_SYRUP + " for syrup\n" + Constants.NUM_FOR_INHALER + " for inhaler");
        while (numOfType != Constants.NUM_FOR_PILLS && numOfType != Constants.NUM_FOR_SYRUP && numOfType != Constants.NUM_FOR_INHALER) {

                    tmp = input.next();
                    numOfType = Integer.parseInt(tmp);

        }
        type = switch (numOfType) {
            case 2 -> Medicine.Type.SYRUP;
            case 3 -> Medicine.Type.INHALER;
            default -> Medicine.Type.PILLS;
        };
        return type;
    }


    //The func prints arrayList
    public static void printArr(ArrayList<Medicine> medicineArrayList) {
        for (Medicine medicine : medicineArrayList) {
            System.out.println(medicine.toString());

        }

    }

    }
