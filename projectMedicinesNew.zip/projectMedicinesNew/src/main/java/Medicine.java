import java.time.LocalDate;
import java.util.Locale;
import exception.*;
public abstract class Medicine {
    //Medicine – an abstract class.
    //Attributes: medicine name, company name, company email,
    //quantity, quantity (num of box), expirationYear (YYYY ), typeOfMedicine (from enum)
    //Methods: constructors, getters and setters, toString(),
    //totalInventory() - an abstract method to calculate the total
    //inventory for each medicine type (ex: 1 Acamol box has 50
    //pills, if we have 1000 boxes = total 1000X50),
    //inStock() – returns true if the quantity > 0 else returns false

    //Attributes
    private String medicineName;
    private String companyName;
    private String companyEmail;
    private int quantity;
    private int expirationYear;
    private double price;
    enum Type {
        INHALER,
        PILLS,
        SYRUP
    }
    private Type type;



    //constant for '@' (char)
    final char SHTRUDEL_CHAR = '@';

    //constant for "@" (String)
    final String SHTRUDEL_STR = "@";

    //constant for "." (String)
    final String DOT_STR = ".";

    //constant for "." (char)
    final char DOT_CHAR = '.';

    //Constructors
    public Medicine()
    {

    }

    public Medicine(String medicineName, String companyName, String companyEmail, double price, int quantity, int expirationYear, Type type) throws MyException {
        setMedicineName(medicineName);
        setCompanyName(companyName);
        setCompanyEmail(companyEmail);
        setPrice(price);
        setQuantity(quantity);
        setExpirationYear(expirationYear);
        setType(type);
    }

    //getters
    public String getMedicineName() {
        return medicineName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getCompanyEmail() {
        return companyEmail;
    }

    public double getPrice() {
        return quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getExpirationYear() {
        return expirationYear;
    }

    public Type getType() {
        return type;
    }


    //setters

    public void setMedicineName(String medicineName) throws NoMedicineNameEntered{

        // Throw a custom exception
            if (medicineName == null || medicineName.trim().length() ==0)
                throw new NoMedicineNameEntered();
            else
                this.medicineName = medicineName.toUpperCase();

            }

    public void setCompanyName(String companyName)  throws NoCompanyNameEntered{
        // Throw a custom exception
        if (companyName == null || companyName.trim().length() == 0)
                throw new NoCompanyNameEntered();

                this.companyName = companyName;
        }


    public void setCompanyEmail(String companyEmail) throws InvalidEmailAddressException , NoCompanyEmailEntered {
        // Throw a custom exception
            if (companyEmail == null)
                throw new NoCompanyEmailEntered();
            else if (companyEmail.contains(SHTRUDEL_STR) && companyEmail.contains(DOT_STR))
                if (companyEmail.charAt(0) != SHTRUDEL_CHAR && !(companyEmail.endsWith(SHTRUDEL_STR)) && companyEmail.lastIndexOf(DOT_CHAR) > companyEmail.lastIndexOf(SHTRUDEL_CHAR))
                    this.companyEmail = companyEmail;
                else
                    throw new InvalidEmailAddressException( getCompanyEmail());
            else
                throw new InvalidEmailAddressException( getCompanyEmail());

    }

    public void setPrice(double price) throws NoPriceEnteredException, InvalidPriceException {

        // Throw a custom exception
            if (price == 0.0)
                throw new NoPriceEnteredException();

            else if(price > 0.0)
                    this.price = price;
                else
                    throw new InvalidPriceException(" " + getPrice());

    }

    public void setQuantity(int quantity) throws InvalidQuantityException {

                if(quantity >= 0) {
                    this.quantity = quantity;
                }
            else
                throw new InvalidQuantityException(" " + getQuantity());
    }

    public void setExpirationYear(int expirationYear) throws invalidExpirationYearException {
        LocalDate yearCurObj ;
        yearCurObj = LocalDate.now();
            if(expirationYear >= yearCurObj.getYear())
                this.expirationYear = expirationYear;
            else
                throw new invalidExpirationYearException(" " + expirationYear);
    }

    public void setType(Type type) {
        this.type = type;
    }


    //Method toString
    public String toString()
    {
     return "Medicine name: " + getMedicineName() + ", Company Name: " + getCompanyName() + ", Company email: "  + getCompanyEmail() + ", Price: "  + getPrice()  +
             ", Quantity: " + getQuantity() + ", Expiration year: " + getExpirationYear() +  ", Type of medicine: " + getType();

    }

    //totalInventory() - an abstract method to calculate the total
    //inventory for each medicine type (ex: 1 Acamol box has 50
    //pills, if we have 1000 boxes = total 1000X50),
    public abstract int totalInventory();

    //inStock() –The method returns true if the quantity > 0 else returns false
    public boolean inStock()
    {
        return ((getQuantity()>0));

    }

}
